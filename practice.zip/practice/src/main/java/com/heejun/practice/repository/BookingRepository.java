package com.heejun.practice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.heejun.practice.model.Booking;

public interface BookingRepository extends JpaRepository<Booking,Long> {
//	public Optional<Booking> findAllBystoreCode(String storeCode);
//	public List<Booking> findBystoreCode(String storeCode);
	
	@Query(value="select time from booking", nativeQuery=true)
	public List<Integer> findBystoreCode(String storeCode);
}
