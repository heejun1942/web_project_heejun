package com.heejun.practice.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.heejun.practice.model.Booking;
import com.heejun.practice.model.Client;
import com.heejun.practice.repository.BookingRepository;
import com.heejun.practice.repository.ClientRepository;

@Controller
public class BookingController {	
	@Autowired
	ClientRepository clientRepository;
	
	@Autowired
	BookingRepository bookingRepository;
	
	@GetMapping("/")
	public String home() {
		return "dugudu/home";
	}
	
	@GetMapping("/store/{storeCode}")
	public String booking(@PathVariable("storeCode") String storeCode, Model model) {
		// �������� ������
//		String storeCode =String.valueOf(id);
		
//		Optional<Booking> status = bookingRepository.findAllBystoreCode(storeCode);		
//		Booking booking = status.orElse(new Booking());
		
		
//		LocalDate today = LocalDate.now();
//		int day=Integer.valueOf(today);
		
//		List<Booking> booking = bookingRepository.findBydayAndstoreCode(day, storeCode)(storeCode);
		
		List<Integer> booking = bookingRepository.findBystoreCode(storeCode);
		model.addAttribute("booking",booking);
		
		// ����ð� ������
		LocalTime nowTime = LocalTime.now();
		int nowHour = nowTime.getHour();
		model.addAttribute("nowHour",nowHour);
		return "dugudu/store";
		
	}
	
	@PostMapping("/store/{storeCode}")
	public String postBooking(@PathVariable("storeCode") String storeCode, @ModelAttribute Client client, @ModelAttribute Booking booking) {
		client.bookingStore=storeCode;
		clientRepository.save(client);
		
//		booking.storeCode=client.bookingStore;
//		booking.storeCode=String.valueOf(id);
		booking.time=client.bookingTime;
		bookingRepository.save(booking);
		
		return "redirect:/store/" + storeCode;
	}
	

}
